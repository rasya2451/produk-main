require('./lib-signal/settings/settings')
const {
  default: makeWASocket,
  prepareWAMessageMedia,
  InteractiveMessage,
  useMultiFileAuthState,
  DisconnectReason,
  generateForwardMessageContent,
  generateWAMessageFromContent,
  fetchLatestBaileysVersion,
  downloadContentFromMessage,
  makeInMemoryStore,
  jidDecode,
  proto,
  Browsers
} = require('baileys')

const axios = require('axios')
const chalk = require('chalk')
const fs = require('fs')
const FileType = require('file-type')
const nou = require('node-os-utils')
const os = require('os')
const path = require('path')
const pino = require('pino')
const PhoneNumber = require('awesome-phonenumber')
const { exec, execSync } = require('child_process')
const {
  imageToWebp,
  imageToWebp3,
  videoToWebp,
  writeExifImg,
  writeExifImgAV,
  writeExifVid
} = require('./x-system/exif')
const {
  getBuffer,
  sleep,
  smsg
} = require('./x-system/myfunc')
const {
  notifGroup
} = require('./lib-signal/data-utils/scrape')
const {
  pickRandom
} = require('./x-system/myfunc')
let setting = JSON.parse(fs.readFileSync('./config-db-set.json'));
let authState = setting.servers
let session = `${sessionName}`
let sesiPath = './' + session
let usePairingCode = pairingCode
if (!fs.existsSync(sesiPath)) {
  fs.mkdirSync(sesiPath, {
    recursive: true
  })
}
const storeFilePath = path.join(sesiPath, 'store.json')
if (!fs.existsSync(storeFilePath)) {
  fs.writeFileSync(storeFilePath, JSON.stringify({
    chats: [],
    contacts: {},
    messages: {},
    presences: {}
  }, null, 4))
}
const debounceWrite = (() => {
  let timeout
  return (callback) => {
    clearTimeout(timeout)
    timeout = setTimeout(() => callback(), 1000)
  }
})()
const store = makeInMemoryStore({
  logger: pino().child({
    level: 'silent',
    stream: 'store'
  })
})
const initialData = JSON.parse(fs.readFileSync(storeFilePath, 'utf-8'))
store.chats = initialData.chats || []
store.contacts = initialData.contacts || {}
store.messages = initialData.messages || {}
store.presences = initialData.presences || {}
setInterval(() => {
  debounceWrite(() => {
    const formattedData = JSON.stringify({
      chats: store.chats || [],
      contacts: store.contacts || {},
      messages: store.messages || {},
      presences: store.presences || {}
    }, null, 4)
    fs.writeFileSync(storeFilePath, formattedData)
  })
}, 10_000)

const consoleLogDetect = console.log;
console.log = function (...args) {
  if (!args.some(arg => typeof arg === "string" && (arg.includes("Closing stale open session") || arg.includes("Closing open session")))) {
    consoleLogDetect(...args);
  }
}

const rainbowColors = [
  '#FF0000',
  '#FF7F00',
  '#FFFF00',
  '#00FF00',
  '#0000FF',
  '#4B0082',
  '#9400D3'
];

const rainbowText = [
  '\n(=#####{>==================- \n',
  '▧ Information',
  `│ » OwnerName : ${global.ownername}`,
  `│ » Bot Type  : Cjs`,
  `│ » Version   : ${global.version}`,
  `│ » WhatsApp  : ${global.owner}`,
  `│ » V.Node Js : ${process.version}`,
  `└───···`
];

function printRainbowText(text, colors) {
  let colorIndex = 0;
  return text.split('').map(char => {
    const color = colors[colorIndex % colors.length];
    colorIndex++;
    return chalk.hex(color)(char);
  }).join('');
}

rainbowText.forEach(line => {
  console.log(printRainbowText(line, rainbowColors));
}); 

try {
global.db = JSON.parse(fs.readFileSync('./data/general-db/database.json'))
if (global.db) global.db.data = {
  users: {},
  chats: {},
  erpg: {},
  media: {},
  others: {},
  settings: {},
  ...(global.db.data || {})
}
} catch (err) {
console.log(`Error save data.. please delete the file database and try run again...`)
}

async function getNumber(prompt) {
  process.stdout.write(prompt)
  return new Promise((resolve, reject) => {
    process.stdin.once('data', (data) => {
      const input = data.toString().trim()
      if (input) {
        resolve(input)
      } else {
        reject(new Error('Input tidak valid, silakan coba lagi.'))
      }
    })
  })
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function startsPairing(Lyrra) {
  if (!Lyrra.authState.creds.registered) {
    let isAuthorized = false;
    let nomor = '';

    let loadInstall = [
      "\nInstalling dependencies...",
      "\nSetting up bot environment...",
      "\nInitializing core modules...",
      "\nLoading complete...",
      "\nConfiguring system settings...",
      "\nFetching required libraries...",
      "\nChecking for updates...",
      "\nEstablishing network connections...",
      "\nOptimizing bot performance...",
      "\nVerifying bot permissions...",
      "\nStarting background services...",
      "\nSynchronizing user data...",
      "\nPreparing media assets...",
      "\nFinalizing setup...",
      "\nSystem ready!"
    ];

    for (let i = 0; i < loadInstall.length; i++) {
      console.clear();
      console.log(chalk.cyan(loadInstall[i]) + '    ');
      await delay(1500);
    }

    console.clear();
    rainbowText.forEach(line => {
      console.log(printRainbowText(line, rainbowColors));
    });

    while (!isAuthorized) {
      console.log(chalk.blue.bold('Masukkan Nomor WhatsApp,\ncontoh : 628xxx'));
      nomor = await getNumber(chalk.blue.bold('Nomor: '));

      if (nomor) {
        try {
          const code = await Lyrra.requestPairingCode(nomor, paiCode);
          console.log(chalk.red.bold('Code Pairing: ') + chalk.reset(code));
          isAuthorized = true;
        } catch (err) {
          console.log(chalk.red.bold('Gagal mendapatkan kode pairing.' + err));
        }
      } else {
        console.log(chalk.red.bold('Nomor tidak boleh kosong. Coba lagi.'));
      }
    }
  }
}

async function startWhatsAppBot() {
  const {
    state,
    saveCreds
  } = await useMultiFileAuthState(sesiPath)
  const {
    version,
    isLatest
  } = await fetchLatestBaileysVersion()
  const Lyrra = makeWASocket({
    logger: pino({
      level: "silent"
    }),
    printQRInTerminal: usePairingCode,
    auth: state,
    version: version,
    browser: Browsers.ubuntu(broswer),
    generateHighQualityLinkPreview: false,
    syncFullHistory: false,
    markOnlineOnConnect: false,
    emitOwnEvents: false
  })
  Lyrra.ev.on('creds.update', saveCreds)
  startsPairing(Lyrra)
  store.bind(Lyrra.ev)

  const processedMessages = new Set()
  Lyrra.ev.on('messages.upsert', async (chatUpdate) => {
    try {
      const mek = chatUpdate.messages[0]
      if (!mek.message) return
      if (processedMessages.has(mek.key.id)) return
      processedMessages.add(mek.key.id)
      mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
      if (mek.key && mek.key.remoteJid === 'status@broadcast') {
  if (setting.autoviewsw === true) {
    let getreact = swreact[Math.floor(Math.random() * swreact.length)];
    await Lyrra.readMessages([mek.key]);
    Lyrra.sendMessage(
      'status@broadcast',
      { react: { text: getreact, key: mek.key } },
      { statusJidList: [mek.key.participant] },
    )
  }
  return
}
      const remoteJid = mek.key.remoteJid
      const userId = mek.key.fromMe ? botNumber : mek.key.participant
      const currentTimestamp = Date.now()
      if (!store.presences) store.presences = {}
      store.presences[userId] = {
        lastOnline: currentTimestamp
      }
      if (!store.messages[remoteJid]) store.messages[remoteJid] = []
      const simplifiedMessage = {
        key: mek.key,
        messageTimestamp: mek.messageTimestamp,
        pushName: mek.pushName || null,
        message: mek.message
      }
      store.messages[remoteJid].push(simplifiedMessage)
      if (store.messages[remoteJid].length > 50) {
        store.messages[remoteJid] = store.messages[remoteJid].slice(-50)
      }
      if (!store.chats.some(chat => chat.id === remoteJid)) {
        store.chats.push({
          id: remoteJid,
          conversationTimestamp: mek.messageTimestamp || Date.now()
        })
      }

      const m = smsg(Lyrra, mek, store)
      require('./Lyrra')(Lyrra, m, chatUpdate, mek, store)
    } catch (err) {
      console.error(err)
    }
  })

  Lyrra.ev.on('call', async (celled) => {
    let botNumber = await Lyrra.decodeJid(Lyrra.user.id)
    let lol = setting.anticall
    if (!lol) return
    for (let loli of celled) {
      if (loli.isGroup == false) {
        if (loli.status == "offer") {
          let nomer = await Lyrra.sendTextWithMentions(loli.from, `*${global.botname}* tidak menerima panggilan ${loli.isVideo ? `vidio!` : `suara!`}. Maaf, Kamu di blokir oleh bot karena telah melanggar aturan bot.`)
          await sleep(5000)
          await Lyrra.updateBlockStatus(loli.from, "block")
        }
      }
    }
  })

   Lyrra.ev.on('group-participants.update', async (anu) => {
    const iswel = db.data.chats[anu.id]?.wlcm || false;
    const isLeft = db.data.chats[anu.id]?.left || false;
    
    let { welcome } = require('./lib-signal/navigation/welcome');
    await welcome(iswel, isLeft, Lyrra, anu);
   })
   
  Lyrra.decodeJid = (jid) => {
    if (!jid) return jid
    if (/:\d+@/gi.test(jid)) {
      let decode = jidDecode(jid) || {}
      return decode.user && decode.server && decode.user + '@' + decode.server || jid
    } else return jid
  }

  Lyrra.ev.on('contacts.update', update => {
    for (let contact of update) {
      let id = Lyrra.decodeJid(contact.id)
      if (store && store.contacts) store.contacts[id] = {
        id,
        name: contact.notify
      }
    }
  })


  Lyrra.getName = (jid, withoutContact = false) => {
    id = Lyrra.decodeJid(jid)
    withoutContact = Lyrra.withoutContact || withoutContact
    let v
    if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
      v = store.contacts[id] || {}
      if (!(v.name || v.subject)) v = Lyrra.groupMetadata(id) || {}
      resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
    })
    else v = id === '0@s.whatsapp.net' ? {
        id,
        name: 'WhatsApp'
      } : id === Lyrra.decodeJid(Lyrra.user.id) ?
      Lyrra.user :
      (store.contacts[id] || {})
    return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
  }

  Lyrra.sendContact = async (jid, kon, quoted = '', opts = {}) => {
    let list = []
    for (let i of kon) {
      list.push({
        displayName: await Lyrra.getName(i + '@s.whatsapp.net'),
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await Lyrra.getName(i + '@s.whatsapp.net')}\nFN:${await Lyrra.getName(i + '@s.whatsapp.net')}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Ponsel\nitem2.EMAIL;type=INTERNET:npofficiall@gmail.com\nitem2.X-ABLabel:Email\nitem3.URL:https://bit.ly/420u6GX\nitem3.X-ABLabel:Instagram\nitem4.ADR:;;Indonesia;;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
      })
    }
    Lyrra.sendMessage(jid, {
      contacts: {
        displayName: `${list.length} Kontak`,
        contacts: list
      },
      ...opts
    }, {
      quoted
    })
  }

  Lyrra.setStatus = (status) => {
    Lyrra.query({
      tag: 'iq',
      attrs: {
        to: '@s.whatsapp.net',
        type: 'set',
        xmlns: 'status',
      },
      content: [{
        tag: 'status',
        attrs: {},
        content: Buffer.from(status, 'utf-8')
      }]
    })
    return status
  }

  Lyrra.public = true
  Lyrra.serializeM = (m) => smsg(Lyrra, m, store)

  Lyrra.getFile = async (PATH, returnAsFilename) => {
    let res, filename
    let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,` [1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await fetch(PATH)).buffer() : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0)
    if (!Buffer.isBuffer(data)) throw new TypeError('Result is not a buffer')
    let type = await FileType.fromBuffer(data) || {
      mime: 'application/octet-stream',
      ext: '.bin'
    }
    if (data && returnAsFilename && !filename)(filename = path.join(__dirname, './' + new Date * 1 + '.' + type.ext), await fs.promises.writeFile(filename, data))
    return {
      res,
      filename,
      ...type,
      data
    }
  }
  
  const ments = (teks) => {return teks.match('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : null}

  Lyrra.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
    let type = await Lyrra.getFile(path, true)
    let {
      res,
      data: file,
      filename: pathFile
    } = type
    if (res && res.status !== 200 || file.length <= 65536) {
      try {
        throw {
          json: JSON.parse(file.toString())
        }
      } catch (e) {
        if (e.json) throw e.json
      }
    }
    let opt = {
      filename
    }
    if (quoted) opt.quoted = quoted
    if (!type) options.asDocument = true
    let mtype = '',
      mimetype = type.mime,
      convert
    if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker'
    else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image'
    else if (/video/.test(type.mime)) mtype = 'video'
    else if (/audio/.test(type.mime))(
      convert = await toAudio(file, type.ext),
      file = convert.data,
      pathFile = convert.filename,
      mtype = 'audio',
      mimetype = 'audio/ogg; codecs=opus'
    )
    else mtype = 'document'
    if (options.asDocument) mtype = 'document'

    delete options.asSticker
    delete options.asLocation
    delete options.asVideo
    delete options.asDocument
    delete options.asImage

    let message = {
      ...options,
      caption,
      ptt,
      [mtype]: {
        url: pathFile
      },
      mimetype,
      fileName: filename || pathFile.split('/').pop()
    }
    let m
    try {
      m = await Lyrra.sendMessage(jid, message, {
        ...opt,
        ...options
      })
    } catch (e) {
      m = null
    } finally {
      if (!m) m = await Lyrra.sendMessage(jid, {
        ...message,
        [mtype]: file
      }, {
        ...opt,
        ...options
      })
      file = null
      return m
    }
  }

  Lyrra.sendFileUrl = async (jid, url, caption, quoted, options = {}) => {
    let mime = ''
    let res = await axios.head(url)
    mime = res.headers['content-type']
    if (mime.split("/")[1] === "gif") {
      return Lyrra.sendMessage(jid, {
        video: await getBuffer(url),
        caption: caption,
        gifPlayback: true,
        ...options
      }, {
        quoted: quoted,
        ...options
      })
    }
    let type = mime.split("/")[0] + "Message"
    if (mime === "application/pdf") {
      return Lyrra.sendMessage(jid, {
        document: await getBuffer(url),
        mimetype: 'application/pdf',
        caption: caption,
        ...options
      }, {
        quoted: quoted,
        ...options
      })
    }
    if (mime.split("/")[0] === "image") {
      return Lyrra.sendMessage(jid, {
        image: await getBuffer(url),
        caption: caption,
        ...options
      }, {
        quoted: quoted,
        ...options
      })
    }
    if (mime.split("/")[0] === "video") {
      return Lyrra.sendMessage(jid, {
        video: await getBuffer(url),
        caption: caption,
        mimetype: 'video/mp4',
        ...options
      }, {
        quoted: quoted,
        ...options
      })
    }
    if (mime.split("/")[0] === "audio") {
      return Lyrra.sendMessage(jid, {
        audio: await getBuffer(url),
        caption: caption,
        mimetype: 'audio/mpeg',
        ...options
      }, {
        quoted: quoted,
        ...options
      })
    }
  }

  Lyrra.sendTextWithMentions = async (jid, text, quoted, options = {}) => Lyrra.sendMessage(jid, {
    text: text,
    mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'),
    ...options
  }, {
    quoted
  })
  
  Lyrra.sendImage = async (jid, path, caption = '', quoted = '', options) => {
    let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await fetch(path)).buffer() : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
    return await Lyrra.sendMessage(jid, {
      image: buffer,
      caption: caption,
      ...options
    }, {
      quoted
    })
  }

  Lyrra.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
    let quoted = message.msg ? message.msg : message
    let mime = (message.msg || message).mimetype || ''
    let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
    const stream = await downloadContentFromMessage(quoted, messageType)
    let buffer = Buffer.from([])
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk])
    }
    let type = await FileType.fromBuffer(buffer)
    let trueFileName = attachExtension ? ('./x-system/' + filename + '.' + type.ext) : './x-system/' + filename
    await fs.writeFileSync(trueFileName, buffer)
    return trueFileName
  }

  Lyrra.sendStickerFromUrl = async (from, PATH, quoted, options = {}) => {
    let {
      writeExif
    } = require('./data-utils/sticker')
    let types = await Lyrra.getFile(PATH, true)
    let {
      filename,
      size,
      ext,
      mime,
      data
    } = types
    let type = '',
      mimetype = mime,
      pathFile = filename
    let media = {
      mimetype: mime,
      data
    }
    pathFile = await writeExif(media, {
      packname: options.packname ? options.packname : '',
      author: options.author ? options.author : author,
      categories: options.categories ? options.categories : []
    })
    await fs.promises.unlink(filename)
    await Lyrra.sendMessage(from, {
      sticker: {
        url: pathFile
      }
    }, {
      quoted
    })
    return fs.promises.unlink(pathFile)
  }

  Lyrra.downloadMediaMessage = async (message) => {
    let mime = (message.msg || message).mimetype || ''
    let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
    const stream = await downloadContentFromMessage(message, messageType)
    let buffer = Buffer.from([])
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk])
    }
    return buffer
  }

  Lyrra.sendAudio = async (jid, path, quoted = '', ptt = false, options) => {
    let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await fetch(path)).buffer() : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
    return await Lyrra.sendMessage(jid, {
      audio: buffer,
      ptt: ptt,
      ...options
    }, {
      quoted
    })
  }

  Lyrra.sendVideo = async (jid, path, gif = false, caption = '', quoted = '', options) => {
    let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await fetch(path)).buffer() : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
    return await Lyrra.sendMessage(jid, {
      video: buffer,
      caption: caption,
      gifPlayback: gif,
      ...options
    }, {
      quoted
    })
  }

  Lyrra.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
    let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await global.getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
    let buffer
    if (options && (options.packname || options.author)) {
      buffer = await writeExifImg(buff, options)
    } else {
      buffer = await imageToWebp(buff)
    }
    await Lyrra.sendMessage(jid, {
      sticker: {
        url: buffer
      },
      ...options
    }, {
      quoted
    })
    return buffer
  }
  
  Lyrra.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
    let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await global.getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
    let buffer
    if (options && (options.packname || options.author)) {
      buffer = await writeExifVid(buff, options)
    } else {
      buffer = await videoToWebp(buff)
    }
    await Lyrra.sendMessage(jid, {
      sticker: {
        url: buffer
      },
      ...options
    }, {
      quoted
    })
    return buffer
  }
  
  Lyrra.sendMedia = async (jid, path, fileName = '', caption = '', quoted = '', options = {}) => {
    let types = await Lyrra.getFile(path, true)
    let {
      mime,
      ext,
      res,
      data,
      filename
    } = types
    if (res && res.status !== 200 || file.length <= 65536) {
      try {
        throw {
          json: JSON.parse(file.toString())
        }
      } catch (e) {
        if (e.json) throw e.json
      }
    }
    let type = '',
      mimetype = mime,
      pathFile = filename
    if (options.asDocument) type = 'document'
    if (options.asSticker || /webp/.test(mime)) {
      let media = {
        mimetype: mime,
        data
      }
      pathFile = await writeExif(media, {
        packname: options.packname ? options.packname : global.packname,
        author: options.author ? options.author : global.author,
        categories: options.categories ? options.categories : []
      })
      await fs.promises.unlink(filename)
      type = 'sticker'
      mimetype = 'image/webp'
    } else if (/image/.test(mime)) type = 'image'
    else if (/video/.test(mime)) type = 'video'
    else if (/audio/.test(mime)) type = 'audio'
    else type = 'document'
    await Lyrra.sendMessage(jid, {
      [type]: {
        url: pathFile
      },
      caption,
      mimetype,
      fileName,
      ...options
    }, {
      quoted,
      ...options
    })
    return fs.promises.unlink(pathFile)
  }

  Lyrra.copyNForward = async (jid, message, forceForward = false, options = {}) => {
    let vtype
    if (options.readViewOnce) {
      message.message = message.message && message.message.ephemeralMessage && message.message.ephemeralMessage.message ? message.message.ephemeralMessage.message : (message.message || undefined)
      vtype = Object.keys(message.message.viewOnceMessage.message)[0]
      delete(message.message && message.message.ignore ? message.message.ignore : (message.message || undefined))
      delete message.message.viewOnceMessage.message[vtype].viewOnce
      message.message = {
        ...message.message.viewOnceMessage.message
      }
    }

    let mtype = Object.keys(message.message)[0]
    let content = await generateForwardMessageContent(message, forceForward)
    let ctype = Object.keys(content)[0]
    let context = {}
    if (mtype != "conversation") context = message.message[mtype].contextInfo
    content[ctype].contextInfo = {
      ...context,
      ...content[ctype].contextInfo
    }
    const waMessage = await generateWAMessageFromContent(jid, content, options ? {
      ...content[ctype],
      ...options,
      ...(options.contextInfo ? {
        contextInfo: {
          ...content[ctype].contextInfo,
          ...options.contextInfo
        }
      } : {})
    } : {})
    await Lyrra.relayMessage(jid, waMessage.message, {
      messageId: waMessage.key.id
    })
    return waMessage
  }

  Lyrra.imgToSticker = async (from, path, quoted, options = {}) => {
    let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await fetchBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
    let buffer
    if (options && (options.packname || options.author)) {
      buffer = await writeExifImg(buff, options)
    } else {
      buffer = await imageToWebp(buff)
    }
    await Lyrra.sendMessage(from, {
      sticker: {
        url: buffer
      },
      ...options
    }, {
      quoted
    })
    return buffer
  }

  Lyrra.vidToSticker = async (from, path, quoted, options = {}) => {
    let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await fetchBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
    let buffer
    if (options && (options.packname || options.author)) {
      buffer = await writeExifVid(buff, options)
    } else {
      buffer = await videoToWebp(buff)
    }
    await Lyrra.sendMessage(from, {
      sticker: {
        url: buffer
      },
      ...options
    }, {
      quoted
    })
    return buffer
  }

  Lyrra.sendButtonsImage = async (chat, judul, teks, buffer, button, wmnye = `${wm}`, num = null, q) => {
    const uploadFile = {
      upload: Lyrra.waUploadToServer
    };
    var imageMessage = await prepareWAMessageMedia({
        image: buffer,
      },
      uploadFile,
    );
    let msg = generateWAMessageFromContent(chat, {
      viewOnceMessage: {
        message: {
          "messageContextInfo": {
            "deviceListMetadata": {},
            "deviceListMetadataVersion": 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            contextInfo: {
              mentionedJid: ments(teks),
              forwardingScore: 9999999,
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                newsletterJid: chjid + "@newsletter",
                newsletterName: `${wm}`,
                serverMessageId: -1
              },
              businessMessageForwardInfo: {
                businessOwnerJid: Lyrra.decodeJid(Lyrra.user.id)
              },
            },
            body: proto.Message.InteractiveMessage.Body.create({
              text: teks
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: wmnye
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              title: judul,
              subtitle: "P",
              imageMessage: imageMessage.imageMessage,
              hasMediaAttachment: true
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: button,
            })
          })
        }
      }
    }, {
      quoted: q
    })
    Lyrra.relayMessage(msg.key.remoteJid, msg.message, {
      messageId: msg.key.id
    })
  }

  Lyrra.sendText = (jid, text, quoted = '', options) => Lyrra.sendMessage(jid, {
    text: text,
    ...options
  }, {
    quoted,
    ...options
  })

  Lyrra.cMod = (jid, copy, text = '', sender = Lyrra.user.id, options = {}) => {
    let mtype = Object.keys(copy.message)[0]
    let isEphemeral = mtype === 'ephemeralMessage'
    if (isEphemeral) {
      mtype = Object.keys(copy.message.ephemeralMessage.message)[0]
    }
    let msg = isEphemeral ? copy.message.ephemeralMessage.message : copy.message
    let content = msg[mtype]
    if (typeof content === 'string') msg[mtype] = text || content
    else if (content.caption) content.caption = text || content.caption
    else if (content.text) content.text = text || content.text
    if (typeof content !== 'string') msg[mtype] = {
      ...content,
      ...options
    }
    if (copy.key.participant) sender = copy.key.participant = sender || copy.key.participant
    else if (copy.key.participant) sender = copy.key.participant = sender || copy.key.participant
    if (copy.key.remoteJid.includes('@s.whatsapp.net')) sender = sender || copy.key.remoteJid
    else if (copy.key.remoteJid.includes('@broadcast')) sender = sender || copy.key.remoteJid
    copy.key.remoteJid = jid
    copy.key.fromMe = sender === Lyrra.user.id

    return proto.WebMessageInfo.fromObject(copy)
  }

  Lyrra.ev.on("connection.update", async (update) => {
    const {
      connection,
      lastDisconnect
    } = update
    if (connection === "close") {
      let reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.statusCode
      if (reason === DisconnectReason.badSession) {
        console.log(`Session error, please delete the session and try again...`)
        process.exit()
      } else if (reason === DisconnectReason.connectionClosed) {
        console.log('Connection closed, reconnecting....')
        startWhatsAppBot()
      } else if (reason === DisconnectReason.connectionLost) {
        console.log('Connection lost from the server, reconnecting...')
        startWhatsAppBot()
      } else if (reason === DisconnectReason.connectionReplaced) {
        console.log('Session connected to another server, please restart the bot.');
        process.exit()
      } else if (reason === DisconnectReason.loggedOut) {
       console.error('Logout details:', {
       error: lastDisconnect?.error,
       stack: lastDisconnect?.error?.stack,
       statusCode: reason
       })
       process.exit()
      } else if (reason === DisconnectReason.restartRequired) {
        console.log('Restart required, restarting connection...')
        startWhatsAppBot()
      } else if (reason === DisconnectReason.timedOut) {
        console.log('Connection timed out, reconnecting...')
        startWhatsAppBot()
      } else {
        console.log(`Unknown DisconnectReason: ${reason}|${connection}`)
        startWhatsAppBot()
      }
    } else if (connection === "connecting") {
      console.log('')
    } else if (connection === "open") {
      console.log(chalk.blue.bold('\nBot WhatsApp Berhasil Terkoneksi...'))
    }
  })
  return Lyrra
}

startWhatsAppBot()

process.on("uncaughtException", (error) => {
  console.error(error)
})
process.on("unhandledRejection", (reason, promise) => {
  console.error("Unhandled Rejection at:", promise, "reason:", reason)
})

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})